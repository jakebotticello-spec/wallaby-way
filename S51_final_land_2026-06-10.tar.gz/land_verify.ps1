# land_verify.ps1 — S51 canon-pass final-land verification
# v1.0 · S51 "Continuance" REF-EDIT · 2026-06-10
# Run from C:\claude-reference AFTER extracting the S51 final-land tarball.
# Deletes EXACTLY two files, both conditional, both receipted:
#   (1) wallaby-way\canon\Batch_Read_Spec_v1.1_2026-06-06.md  — only on md5 match vs the history copy
#   (2) wallaby-way\tasks\lessons_S51_append.md               — only after lessons.md verifies (a)-(i)
# Sweep scope (rider): active\ + wallaby-way\canon\ + wallaby-way\CLAUDE.md + wallaby-way\tasks\lessons.md
# NEVER touches nodes\ or runs\ (corpus-derived; pattern-matching there is the untrusted case).

$ErrorActionPreference = 'Stop'
$script:fails = New-Object System.Collections.ArrayList
$LifetimeFigure = '$182'   # baked at ship time; '(console-verify)' flag applies if estimated

function Report([bool]$ok, [string]$msg) {
    if ($ok) { Write-Host ('PASS — ' + $msg) -ForegroundColor Green }
    else     { Write-Host ('FAIL — ' + $msg) -ForegroundColor Red
               [void]$script:fails.Add($msg) }
}
function Info([string]$msg) { Write-Host ('INFO — ' + $msg) -ForegroundColor Yellow }

# ---------- Part 0: location sanity ----------
if (-not ((Test-Path 'active') -and (Test-Path 'wallaby-way\canon'))) {
    Write-Host 'FAIL — not at the repo root (active\ or wallaby-way\canon\ missing). Run from C:\claude-reference. Nothing checked, nothing deleted.' -ForegroundColor Red
    exit 1
}

# ---------- Part A: v1.1 supersede (conditional delete #1) ----------
$canonV11 = 'wallaby-way\canon\Batch_Read_Spec_v1.1_2026-06-06.md'
$histV11  = 'history\superseded-specs\Batch_Read_Spec_v1.1_2026-06-06.md'
if ((Test-Path $canonV11) -and (Test-Path $histV11)) {
    $h1 = (Get-FileHash -Algorithm MD5 -Path $canonV11).Hash
    $h2 = (Get-FileHash -Algorithm MD5 -Path $histV11).Hash
    if ($h1 -eq $h2) {
        Remove-Item -Path $canonV11
        Report $true ('v1.1 supersede: md5 MATCH (canon ' + $h1 + ' == history ' + $h2 + ') — canon copy DELETED. Receipt above.')
    } else {
        Write-Host ('FAIL — v1.1 supersede: md5 MISMATCH (canon ' + $h1 + ' vs history ' + $h2 + '). DELETED NOTHING. Resolve by eye before re-running.') -ForegroundColor Red
        exit 1
    }
} else {
    Write-Host ('FAIL — v1.1 supersede: a copy is missing (canon present: ' + (Test-Path $canonV11) + ' / history present: ' + (Test-Path $histV11) + '). DELETED NOTHING.') -ForegroundColor Red
    Write-Host '       NOTE: if the canon copy is absent because a PRIOR run already superseded it, that is expected — but per spec this run halts here; re-extract or verify by eye.' -ForegroundColor Yellow
    exit 1
}

# ---------- Part B: lessons (a)-(i) verify (conditional delete #2) ----------
$lessonsPath = 'wallaby-way\tasks\lessons.md'
$appendPath  = 'wallaby-way\tasks\lessons_S51_append.md'
$lessonTitles = @(
    'Rate constants, never re-derived',
    'The wrong hand',
    'A pile count and a session-net count are different units',
    'Run the one-line arithmetic against inherited canon numbers',
    'One task in two windows breaks the receipt chain',
    'the reader obeys payload instructions',
    'Narrative numbers vs clock-derived numbers',
    'Prefix-twin UUIDs transpose',
    'Tombstones name the class'
)
if (Test-Path $lessonsPath) {
    $lt = Get-Content -Raw -Encoding UTF8 -Path $lessonsPath
    $missing = @($lessonTitles | Where-Object { -not $lt.Contains($_) })
    if ($missing.Count -eq 0) {
        Report $true 'lessons.md carries all 9 S51 entries (a)-(i).'
        if (Test-Path $appendPath) {
            Remove-Item -Path $appendPath
            Report $true ('lessons_S51_append.md (the tarball-1 shipping container) DELETED — content verified merged into lessons.md. Receipt: this line.')
        } else {
            Info 'lessons_S51_append.md already absent — nothing to delete (acceptable; delete #2 is conditional).'
        }
    } else {
        Report $false ('lessons.md is MISSING entries: ' + ($missing -join ' | ') + ' — append file NOT deleted.')
    }
} else {
    Report $false 'wallaby-way\tasks\lessons.md not found — append file NOT deleted.'
}

# ---------- Part C: the sweep (rider scope) ----------
$scopeFiles = @()
$scopeFiles += Get-ChildItem -Path 'active' -Filter '*.md' -File | ForEach-Object { $_.FullName }
$scopeFiles += Get-ChildItem -Path 'wallaby-way\canon' -Filter '*.md' -File | ForEach-Object { $_.FullName }
if (Test-Path 'wallaby-way\CLAUDE.md') { $scopeFiles += (Resolve-Path 'wallaby-way\CLAUDE.md').Path }
if (Test-Path $lessonsPath)            { $scopeFiles += (Resolve-Path $lessonsPath).Path }

function Find-Lines([string]$literal) {
    $hits = @()
    foreach ($f in $scopeFiles) {
        $n = 0
        foreach ($line in (Get-Content -Encoding UTF8 -Path $f)) {
            $n++
            if ($line.Contains($literal)) { $hits += [pscustomobject]@{File=$f; Line=$n; Text=$line} }
        }
    }
    return ,$hits
}

# C1 — "29,175": exactly the 4 adjudicated spots + the ONE named exception (lessons (d), OC FILE-6 draft text)
$hits = Find-Lines '29,175'
$sanctioned = 0; $exception = 0; $rogue = @()
foreach ($h in $hits) {
    if ($h.Text.Contains('[S51 fix:') -or $h.Text.Contains('THE 29,175 UNIT-FIX')) { $sanctioned++ }
    elseif ($h.File.EndsWith('lessons.md') -and $h.Text.Contains('29,175')) { $exception++ }
    else { $rogue += ($h.File + ':' + $h.Line) }
}
Report (($sanctioned -eq 4) -and ($rogue.Count -eq 0)) ('"29,175" at exactly the 4 adjudicated spots (found ' + $sanctioned + '; rogue: ' + $(if ($rogue.Count){$rogue -join ', '}else{'none'}) + ')')
if ($exception -gt 0) { Info ('"29,175" also present in lessons.md lesson (d) x' + $exception + ' — NAMED EXCEPTION: the literal is OC FILE-6 draft-text fact; flagged to OC in the delta-manifest.') }

# C2-C4 — zero-tolerance literals
foreach ($pair in @(@('[PENDING-RECEIPT]','zero "[PENDING-RECEIPT]" in scope'), @('439/440','zero "439/440" in scope'), @('2,981','zero "2,981" in scope'))) {
    $hits = Find-Lines $pair[0]
    Report ($hits.Count -eq 0) ($pair[1] + $(if ($hits.Count){' — FOUND: ' + (($hits | ForEach-Object { $_.File + ':' + $_.Line }) -join ', ')}else{''}))
}

# C5 — "73a1" only inside transposition notes (line must carry "ASSISTANT")
$hits = Find-Lines '73a1'
$bad = @($hits | Where-Object { -not $_.Text.Contains('ASSISTANT') })
Report ($bad.Count -eq 0) ('"73a1" only inside transposition notes (' + $hits.Count + ' hit(s), rogue: ' + $(if ($bad.Count){($bad | ForEach-Object { $_.File + ':' + $_.Line }) -join ', '}else{'none'}) + ')')

# C6 — spend figure: zero stale "$177", lifetime figure present
$old = Find-Lines '$177'
Report ($old.Count -eq 0) ('zero stale "$177" in scope' + $(if ($old.Count){' — FOUND: ' + (($old | ForEach-Object { $_.File + ':' + $_.Line }) -join ', ')}else{''}))
$new = Find-Lines $LifetimeFigure
Report ($new.Count -ge 1) ('lifetime spend figure "' + $LifetimeFigure + '" present (' + $new.Count + ' spot(s))')

# C7 — ANCHOR masthead v35
$anchorLines = Get-Content -Encoding UTF8 -Path 'wallaby-way\canon\ANCHOR_apparatus.md' -TotalCount 2
Report ($anchorLines[1].StartsWith('*v35')) 'ANCHOR masthead reads v35'

# C8-C11 — file presence/absence
Report (Test-Path 'wallaby-way\canon\Batch_Read_Spec_v1.2_2026-06-10.md') 'Batch_Read_Spec_v1.2 present in canon\'
Report (-not (Test-Path $canonV11)) 'Batch_Read_Spec_v1.1 GONE from canon\'
Report (Test-Path 'wallaby-way\canon\whale_registry.md') 'canon\whale_registry.md exists'
Report (Test-Path 'wallaby-way\nodes\quarantine\_SUPERSEDED_S51.md') 'nodes\quarantine\_SUPERSEDED_S51.md exists'
$fc = Get-Content -Raw -Encoding UTF8 -Path 'wallaby-way\canon\FLOOR_COUNTS.md'
Report ($fc.Contains('S51 INTERIM')) 'FLOOR_COUNTS carries the S51 INTERIM header'

# ---------- Summary ----------
Write-Host ''
Write-Host '================ SUMMARY ================'
if ($script:fails.Count -eq 0) {
    Write-Host 'ALL PASS — READY TO COMMIT' -ForegroundColor Green
    exit 0
} else {
    Write-Host ('FAILURES (' + $script:fails.Count + '):') -ForegroundColor Red
    foreach ($f in $script:fails) { Write-Host ('  - ' + $f) -ForegroundColor Red }
    exit 1
}
