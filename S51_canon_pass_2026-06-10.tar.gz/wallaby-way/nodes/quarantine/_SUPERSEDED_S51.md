# _SUPERSEDED_S51.md — the supersede record (label, never delete)
*Authored by S51 "Continuance" REF-EDIT, 2026-06-10, for `wallaby-way/nodes/quarantine/`. This file LABELS artifacts as superseded — nothing listed here is deleted. The floor is immortal; the record stays whole; labels carry the truth forward.*
*Companion ledger: `_PARTIAL_MOVES_S51.md` (same dir) — the move-by-move record of the S50→S51 partial-catalog relocations. Read it for the file-level mechanics; read this file for the canonical disposition of record.*

---

## 1. SUPERSEDED-BY-S51-RE-READ — the 11 partial catalogs

The snapshot-boundary bug (S50) rendered every multi-snapshot conv PARTIAL at read time. All 11 partial catalogs below were re-read WHOLE in S51 under the patched extractor (all snapshots, deduped on `msg_uuid`, highest scrub version), with the payload-vs-floor integrity check passed. **The S51 catalogs in `nodes/harvested/` are canonical; the artifacts below are SUPERSEDED — kept as the record of the partial reads, never to be merged, counted, or parsed for identity.**

| conv_uuid | partial extent at S50 read | superseded by |
|---|---|---|
| `176476ae` | 211/223 msgs | S51 chunk read ×3 (density-bounced from the batch; 62 nodes) |
| `6cabbba6` | 26/56 | S51 whole re-read |
| `70ec4abb` | 25/69 | S51 whole re-read |
| `955cce09` | 27/55 | S51 whole re-read |
| `a7796a13` | 310/316 | S51 whole re-read |
| `c33596c3` | 78/88 (entered harvested via the S50 wave-1 anchor repair — repair MOOT) | S51 whole re-read |
| `cda6d5d1` | 112/114 | S51 whole re-read |
| `fcbd24fa` | 62/84 | S51 whole re-read |
| `39589260` | 8/109 — **S47-era read; blast-radius census find (new at S51)** | S51 whole re-read |
| `5d0eba7c` | 52/60 — **S47-era read; blast-radius census find (new at S51)** | S51 whole re-read |
| `2526703b` | 48/80 — **missed-supersede; blast-radius census find (new at S51)** | S51 whole re-read |

*(Blast radius was 12 convs, not the 9 known at the S50 handoff — zero of the 12 were WHOLE. The 12th, `c00ef343`, is §2 below: its S50 artifact was a quarantine corpse, not a partial catalog.)*

## 2. SUPERSEDED-BY-S51-RE-READ — c00ef343's artifacts

`c00ef343` rendered 1/37 msgs at the S50 read and was caught by the stub gate (quarantined — it never persisted a partial catalog). Its S50-era quarantine artifacts are **SUPERSEDED** by the S51 whole re-read (37/37 proven on the patched extractor). Artifacts labeled, kept.

## 3. RESOLVED-ARTIFACTS-KEPT — the 7 stale `.quarantined.md` corpses

The following quarantine corpses belong to convs that were legitimately resolved (repaired, re-fired clean, or re-read whole) — the corpses are RESOLVED history, kept as the record of the trips:

`6674652b` · `6975eda9` · `c33596c3` · `c13cd255` · `ec4e54c8` · `4dc6e0d2` · `554b4f73`

## 4. MERGE_MANIFEST_S47 — two rows superseded

`MERGE_MANIFEST_S47.md` rows for **`39589260`** and **`5d0eba7c`** are **superseded by the S51 whole re-reads** (both were S47-era partial reads exposed by the blast-radius census). The manifest itself is NOT edited (it is the S47-era record); this file is the supersede pointer of record. Current pile counts: `canon/FLOOR_COUNTS.md` (S51 interim).

---

*Disposition law: SUPERSEDED ≠ deleted. Every artifact above remains on disk under its label. Node identity is `conv_uuid` + `anchor_msg` from CONTENT — no superseded file is ever parsed for identity or counted in the pile.*
